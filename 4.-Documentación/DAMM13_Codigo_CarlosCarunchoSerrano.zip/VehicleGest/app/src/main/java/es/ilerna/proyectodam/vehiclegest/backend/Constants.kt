package es.ilerna.proyectodam.vehiclegest.backend

class Constants {
    //TODO Patrón de contraseña
    val passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$"
}